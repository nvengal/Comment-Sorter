In order to run this script you will need to set up a few things:
1. Export your excel spreadsheet as a .csv file
	Open your spreadsheet and click on File -> Export -> Change File Type
	Select "CSV (Comma Delimited) (*.csv)" in the "Other File Types" Category
	Save the file to the folder in which this file is located
2. Double click on the Run.cmd file
3. It will prompt you to enter a file name.
	Enter the name of the file that you saved to this location in step 1.
	For example, if the file is name list_of_comments, enter list_of_comments.csv
	After typing in the file name press enter
4. If the process is successful you should see the text "COMMENTS SUCCESSFULLY SORTED"
5. You should see a new folder inside of this folder called "CATEGORIZED_COMMENTS_OUTPUT"
6. Inside the folder you will find many excel files.
	The names of the files correspond to a category 
	and comments within the file should belong to that category.
	Uncatagorized comments can be found in the Miscellaneous category.

IMPROTANT Do THIS FIRST:

Copy and paste the following code into a file in notepad.
It is important that you use note pad. Name the file whatever you want but save it to this folder.
Then rename the file 'Run.cmd' without the quotes

Copy the code from below the dotted line
----------------------------------------
java CommentParser
cmd /k
